export enum UserRole {
    PHYSICIAN = 'Physician',
    PATIENT = 'Patient',
    NURSE = 'Nurse',
    ADMIN = 'Admin'
}