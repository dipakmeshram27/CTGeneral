export class usernotes{
    message:String;
    date:Date;
    role:string;
    urgency:boolean;
    firstName:string;
    title:string;
    lastName:string;
    noteId:number;
    recieverId:number;
    reply:String;
}
