export class User {
    title:String;
    userId : number;
    firstName:string;
    lastName:string;
    role:number;
    password:string;
    email:string;
    status:string;
    createdDate:string;
    updatedDate:string;
    phoneNumber: number;
    dateOfBirth: string;
}
