export class Notes {
    message:string;
    senderId : number;
    recieverId:number;
    urgency:boolean;
    reply:String;
    noteId:number;
}
