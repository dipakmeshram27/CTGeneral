export class SetStatus
{
    status :string;
    userId : number;
}