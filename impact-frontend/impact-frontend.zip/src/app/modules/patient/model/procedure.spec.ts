import { Procedure } from './procedure';

describe('Procedure', () => {
  it('should create an instance', () => {
    expect(new Procedure()).toBeTruthy();
  });
});
