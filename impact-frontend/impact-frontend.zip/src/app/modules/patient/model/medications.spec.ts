import { Medications } from './medications';

describe('Medications', () => {
  it('should create an instance', () => {
    expect(new Medications()).toBeTruthy();
  });
});
