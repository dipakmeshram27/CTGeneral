export class Diagnosis {
    diagnosisCode: number;
    diagnosisName: string;
    description : string;
}
