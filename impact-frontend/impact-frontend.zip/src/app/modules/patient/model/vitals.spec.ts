import { Vitals } from './vitals';

describe('Vitals', () => {
  it('should create an instance', () => {
    expect(new Vitals()).toBeTruthy();
  });
});
