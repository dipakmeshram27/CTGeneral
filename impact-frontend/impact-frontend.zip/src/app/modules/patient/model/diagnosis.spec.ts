import { Diagnosis } from './diagnosis';

describe('Diagnosis', () => {
  it('should create an instance', () => {
    expect(new Diagnosis()).toBeTruthy();
  });
});
