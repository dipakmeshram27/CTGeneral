export class Medications {

    drugId: Number;
    drugName: string;
    drugForm: string;
    discription: string;
    appointmentId:number;
}
