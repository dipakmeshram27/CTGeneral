export class Procedure {
    procedureCode: number;
    procedureName: string;
    discription: string;
}


