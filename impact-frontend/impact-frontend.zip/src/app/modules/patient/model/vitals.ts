export class Vitals {
    height: number;
    weight: number;
    bloodPressure: string;
    bodyTemperature:number;
    respirationRate:number;
    appointmentId:number;
}
