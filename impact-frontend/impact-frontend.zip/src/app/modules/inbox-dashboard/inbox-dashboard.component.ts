import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inbox-dashboard',
  templateUrl: './inbox-dashboard.component.html',
  styleUrls: ['./inbox-dashboard.component.css']
})
export class InboxDashboardComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
